row.status_id = 0;
row.status_message = null;
