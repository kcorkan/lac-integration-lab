//TODO:  See US3114
// if (req.resourceName == "_toJira"){
//     log.debug('last_updated' + row.last_updated);
    
//     var last_updated = row.last_updated;
    
//     var obj = logicContext.createPersistentBean('jira_action');
//     obj.jira_object_ident = row.ident;
//     obj.action = "ISSUELINK";
//     obj.last_updated = last_updated;
//     logicContext.insert(obj);
// }
// log.debug('resource' + req.resourceName)

