// Listener code goes here or check out examples ( see top right dropdown menu ) 
//var settings = listenerUtil.restGet(url, params, settings);

//TODO these things should be loaded from the database 
gCFG.setAuthToken("J8KDHTu7hRHIC7Gl1p1P");
gCFG.initialize("catalystUrl","http://dev-1-lac-1-env.eawarvnwcf.us-east-1.elasticbeanstalk.com/rest/default/orchestrator/v1/catalyst");
gCFG.initialize("jiraApiIdent", 2);  
gCFG.initialize("arrayDelimiter","|");
