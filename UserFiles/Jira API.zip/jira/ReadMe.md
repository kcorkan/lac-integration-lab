# API
This folder contains the content of your API definition.
Name: Jira API
URL Fragment: jira
Comments: API to interact with JIRA systems
