return {
      "fields": {
        "*": {
          "fieldDef": {
            "id": {
              "*": {
                "@(3,system_value)": "fields.&1"
              }
            }
          }
        }
      }
    };
