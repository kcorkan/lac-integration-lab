return [{
    "name":"Board",
    "id": "originBoardId",
    "schema_type":"board"
},{
  "name": "state",
  "id": "state"
},{
   "name":"name",
    "id": "name"
    
},{
    "name":"startDate",
    "id":"startDate"
},{
    "name":"endDate",
    "id":"endDate"
},{
    "name":"goal",
    "id":"goal"
}];
