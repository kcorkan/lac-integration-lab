
return {
      "target_data": {
        "*": {
          "$": "fields[#2].fieldDef.name",
          "@": "fields[#2].user_value"
        }
      }
    };

