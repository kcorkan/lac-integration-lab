# API
This folder contains the content of your API definition.
Name: Orchestrator API
URL Fragment: orchestrator
Comments: API to orchestrate synchronization between defined systems.
