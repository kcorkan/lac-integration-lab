var new_ordinal =  parameters.ordinal || 1;
row.ordinal = new_ordinal;
return {"ordinal": row.ordinal};
