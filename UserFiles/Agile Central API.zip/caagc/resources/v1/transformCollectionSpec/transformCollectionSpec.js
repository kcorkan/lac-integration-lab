return {
      "collections": {
        "*": {
          "system_value": "@(1,fieldDef.id).CollectionItems.[]._ref"
        }
      }
    };
