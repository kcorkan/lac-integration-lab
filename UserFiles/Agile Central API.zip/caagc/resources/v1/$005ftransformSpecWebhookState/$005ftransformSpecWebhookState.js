return {
  "*": {
    "value": "@(1,name)"
  }
};
