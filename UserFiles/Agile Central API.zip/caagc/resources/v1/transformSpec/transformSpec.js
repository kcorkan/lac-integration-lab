return {
    "fields": {
      "*": {
        "system_value": "@(3,object_type).@(1,fieldDef.id)"
      }
    }
};
