# API
This folder contains the content of your API definition.
Name: Agile Central API
URL Fragment: caagc
Comments: API to interact with Agile Central systems
