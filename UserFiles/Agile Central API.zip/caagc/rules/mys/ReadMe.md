# RULES
This folder contains rules for entities in prefix mys.
