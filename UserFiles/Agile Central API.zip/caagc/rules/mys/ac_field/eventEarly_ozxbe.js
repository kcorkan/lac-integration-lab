if (row.ac_field_def.system_attribute === null || row.ac_field_def.system_attribute == row.ac_field_def.user_attribute){
    row.system_value = row.user_value; 
}
